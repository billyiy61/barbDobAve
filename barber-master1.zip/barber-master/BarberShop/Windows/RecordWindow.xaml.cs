﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BarberShop.Windows
{
    /// <summary>
    /// Логика взаимодействия для RecordWindow.xaml
    /// </summary>
    public partial class RecordWindow : Window
    {
        public RecordWindow()
        {
            InitializeComponent();
        }
        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            MainWindow mainWindow = new MainWindow();
            mainWindow.ShowDialog();
            this.Close();
        }
        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void FNameTxbx_GotFocus(object sender, RoutedEventArgs e)
        {
            if (FNameTxbx.Text == "Имя")
            {
                FNameTxbx.Text = "";
                FNameTxbx.Foreground = Brushes.Black;
            }
        }

        private void FNameTxbx_LostFocus(object sender, RoutedEventArgs e)
        {
            if (FNameTxbx.Text == "")
            {
                FNameTxbx.Text = "Имя";
                FNameTxbx.Foreground = Brushes.LightGray;
            }
        }

        private void LNameTxBx_GotFocus(object sender, RoutedEventArgs e)
        {
            if (LNameTxBx.Text == "Фамилия")
            {
                LNameTxBx.Text = "";
                LNameTxBx.Foreground = Brushes.Black;
            }
        }

        private void LNameTxBx_LostFocus(object sender, RoutedEventArgs e)
        {
            if (LNameTxBx.Text == "")
            {
                LNameTxBx.Text = "Фамилия";
                LNameTxBx.Foreground = Brushes.LightGray;
            }
        }

        private void PMameTxBx_GotFocus(object sender, RoutedEventArgs e)
        {
            if (PMameTxBx.Text == "Телефон")
            {
                PMameTxBx.Text = "";
                PMameTxBx.Foreground = Brushes.Black;
            }
        }

        private void PMameTxBx_LostFocus(object sender, RoutedEventArgs e)
        {
            if (PMameTxBx.Text == "")
            {
                PMameTxBx.Text = "Телефон";
                PMameTxBx.Foreground = Brushes.LightGray;
            }
        }

        private void EmpLogxBx_GotFocus(object sender, RoutedEventArgs e)
        {
            if (EmpLogxBx.Text == "Логин")
            {
                EmpLogxBx.Text = "";
                EmpLogxBx.Foreground = Brushes.Black;
            }
        }

        private void EmpLogxBx_LostFocus(object sender, RoutedEventArgs e)
        {
            if (EmpLogxBx.Text == "")
            {
                EmpLogxBx.Text = "Логин";
                EmpLogxBx.Foreground = Brushes.LightGray;
            }
        }
    }
}
